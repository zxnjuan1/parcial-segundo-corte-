import { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, NavLink, Link, useLocation } from "react-router-dom";

const money = (n) =>
  new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n);

const MENU = [
  { id: 1, cat: "Tacos", name: "Taco al Pastor", em: "🌮", price: 6500, d: "Cerdo adobado, piña, cebolla y cilantro en tortilla de maíz." },
  { id: 2, cat: "Tacos", name: "Taco de Pollo", em: "🌮", price: 6000, d: "Pollo desmechado con guacamole y salsa verde." },
  { id: 3, cat: "Tacos", name: "Combo 3 Tacos", em: "🌮", price: 17000, d: "Tres tacos a elección con salsa de la casa." },
  { id: 4, cat: "Burritos y más", name: "Burrito Grande", em: "🌯", price: 19000, d: "Arroz, frijol, carne, queso y pico de gallo." },
  { id: 5, cat: "Burritos y más", name: "Quesadilla", em: "🧀", price: 14000, d: "Tortilla de harina rellena de queso gratinado y pollo." },
  { id: 6, cat: "Burritos y más", name: "Nachos con Queso", em: "🫓", price: 15000, d: "Totopos, queso fundido, jalapeños y guacamole." },
  { id: 7, cat: "Acompañantes", name: "Guacamole", em: "🥑", price: 7000, d: "Aguacate fresco con limón y totopos." },
  { id: 8, cat: "Acompañantes", name: "Maíz Asado", em: "🌽", price: 8000, d: "Mazorca con mayonesa, queso y chile en polvo." },
  { id: 9, cat: "Bebidas", name: "Agua de Jamaica", em: "🍹", price: 5500, d: "Refrescante, hecha con flor de jamaica." },
  { id: 10, cat: "Bebidas", name: "Limonada de Coco", em: "🥥", price: 9000, d: "Cremosa y bien fría." },
];
const CATS = ["Todo", ...new Set(MENU.map((m) => m.cat))];

function ScrollTop() {
  const { pathname } = useLocation();
  useEffect(() => window.scrollTo(0, 0), [pathname]);
  return null;
}

function Header({ count }) {
  return (
    <header>
      <div className="bar">
        <Link to="/" className="brand">🌮 TACO FIESTA</Link>
        <nav>
          <NavLink to="/" end>Inicio</NavLink>
          <NavLink to="/menu">Menú</NavLink>
          <NavLink to="/pedidos">
            Mi pedido {count > 0 && <span className="badge">{count}</span>}
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

function Home() {
  return (
    <div>
      <section className="hero">
        <h1>¡ARMA TU PEDIDO<br />EN SEGUNDOS!</h1>
        <p>Sin papel y sin filas. Elige tus favoritos, mira el total antes de pagar y confírmalo.</p>
        <Link className="btn" to="/menu">Ver el menú →</Link>
        <div className="big">🌮</div>
      </section>
      <section className="steps">
        <div className="card"><span>📋</span><h3>1. Mira el menú</h3><p>Tacos, burritos, acompañantes y bebidas.</p></div>
        <div className="card"><span>🛒</span><h3>2. Arma tu pedido</h3><p>Agrega o quita productos cuando quieras.</p></div>
        <div className="card"><span>💰</span><h3>3. Conoce el total</h3><p>Verás cuánto pagarás antes de confirmar.</p></div>
      </section>
    </div>
  );
}

function Menu({ cart, add, remove, count, total }) {
  const [cat, setCat] = useState("Todo");
  const items = MENU.filter((m) => cat === "Todo" || m.cat === cat);
  return (
    <div>
      <h2 className="title">Nuestro menú</h2>
      <div className="tabs">
        {CATS.map((c) => (
          <button key={c} className={"tab " + (c === cat ? "on" : "")} onClick={() => setCat(c)}>{c}</button>
        ))}
      </div>
      <div className="grid">
        {items.map((m) => {
          const q = cart[m.id] || 0;
          return (
            <div className="card item" key={m.id}>
              <div className="em">{m.em}</div>
              <h3>{m.name}</h3>
              <p>{m.d}</p>
              <div className="row">
                <span className="price">{money(m.price)}</span>
                {q === 0 ? (
                  <button className="btn red" onClick={() => add(m.id)}>Agregar</button>
                ) : (
                  <div className="qty">
                    <button aria-label="Quitar" onClick={() => remove(m.id)}>−</button>
                    <b>{q}</b>
                    <button aria-label="Agregar" onClick={() => add(m.id)}>+</button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
      {count > 0 && (
        <Link className="fab" to="/pedidos">
          <span>🛒 {count} producto{count > 1 ? "s" : ""}</span>
          <span>{money(total)} · Ver pedido →</span>
        </Link>
      )}
    </div>
  );
}

function Orders({ cart, add, remove, total, count, orders, confirm }) {
  const [name, setName] = useState("");
  const [type, setType] = useState("Para llevar");
  const [note, setNote] = useState("");
  const [msg, setMsg] = useState(null);
  const lines = MENU.filter((m) => cart[m.id]);

  const submit = () => {
    if (!name.trim()) {
      setMsg({ error: true, text: "Escribe tu nombre para confirmar." });
      return;
    }
    const n = confirm({ name: name.trim(), type, note });
    setMsg({ error: false, text: `¡Pedido #${n} confirmado! Te llamaremos por tu nombre cuando esté listo.` });
    setName("");
    setNote("");
  };

  return (
    <div>
      <h2 className="title">Mi pedido</h2>
      {msg && <div className={"ok " + (msg.error ? "err" : "")}>{msg.text}</div>}
      <div className="two">
        <div className="card">
          {lines.length === 0 ? (
            <div className="empty">
              <span>🛒</span>Aún no has agregado nada.<br /><br />
              <Link className="btn red" to="/menu">Ir al menú</Link>
            </div>
          ) : (
            <div>
              {lines.map((m) => (
                <div className="line" key={m.id}>
                  <span className="em">{m.em}</span>
                  <div><b>{m.name}</b><div className="mute">{money(m.price)} c/u</div></div>
                  <div className="right">
                    <div className="qty">
                      <button onClick={() => remove(m.id)}>−</button>
                      <b>{cart[m.id]}</b>
                      <button onClick={() => add(m.id)}>+</button>
                    </div>
                    <div className="price small">{money(m.price * cart[m.id])}</div>
                  </div>
                </div>
              ))}
              <div className="total"><span>Total a pagar</span><span>{money(total)}</span></div>
            </div>
          )}
        </div>

        <div className="card">
          <h3 className="sub">Datos del pedido</h3>
          <label>Tu nombre</label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej: Camila" />
          <label>¿Cómo lo quieres?</label>
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option>Para llevar</option>
            <option>Comer aquí</option>
          </select>
          <label>Notas (opcional)</label>
          <textarea rows="2" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Sin cebolla, salsas aparte…" />
          <div className="total"><span>Total</span><span>{money(total)}</span></div>
          <button className="btn red full" disabled={count === 0} onClick={submit}>Confirmar pedido</button>
          <p className="mute">Pagas en caja al recoger tu pedido.</p>
        </div>
      </div>

      {orders.length > 0 && (
        <section style={{ marginTop: 28 }}>
          <h2 className="title">Pedidos confirmados</h2>
          <div className="grid">
            {[...orders].reverse().map((o) => (
              <div className="card" key={o.n}>
                <div className="row"><b>#{o.n} · {o.name}</b><span className="tag">{o.type}</span></div>
                <ul>{o.lines.map((l) => <li key={l.name}>{l.q}× {l.name}</li>)}</ul>
                {o.note && <div className="mute">📝 {o.note}</div>}
                <div className="price">{money(o.total)}</div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

export default function App() {
  const [cart, setCart] = useState({});
  const [orders, setOrders] = useState(() => {
    try { return JSON.parse(localStorage.getItem("tf-orders") || "[]"); } catch { return []; }
  });
  useEffect(() => {
    try { localStorage.setItem("tf-orders", JSON.stringify(orders)); } catch { /* sin almacenamiento */ }
  }, [orders]);

  const add = (id) => setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
  const remove = (id) =>
    setCart((c) => {
      const n = { ...c };
      if (n[id] > 1) n[id]--; else delete n[id];
      return n;
    });
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const total = MENU.reduce((s, m) => s + m.price * (cart[m.id] || 0), 0);

  const confirm = ({ name, type, note }) => {
    const n = (orders.length ? Math.max(...orders.map((o) => o.n)) : 100) + 1;
    const lines = MENU.filter((m) => cart[m.id]).map((m) => ({ name: m.name, q: cart[m.id] }));
    setOrders((o) => [...o, { n, name, type, note, lines, total }]);
    setCart({});
    return n;
  };

  const props = { cart, add, remove, count, total, orders, confirm };

  return (
    <BrowserRouter>
      <ScrollTop />
      <Header count={count} />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/menu" element={<Menu {...props} />} />
          <Route path="/pedidos" element={<Orders {...props} />} />
        </Routes>
      </main>
      <footer>Taco Fiesta · Prototipo de toma de pedidos</footer>
    </BrowserRouter>
  );
}
